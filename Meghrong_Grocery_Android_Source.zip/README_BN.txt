Meghrong Grocery Android APK source

এই প্রজেক্টটি আপনার ওয়েবসাইট https://meghgrocery.netlify.app-কে Android WebView অ্যাপে চালায়।

গুরুত্বপূর্ণ:
- APK তৈরি করতে GitHub Actions-এ Android build চালানো হবে।
- অ্যাপটি অনলাইনে ওয়েবসাইট লোড করে; ওয়েবসাইট/অর্ডার ডেটাবেস নিজে থেকে অফলাইনে কাজ করবে না।
- WhatsApp লিংকগুলো Android-এ WhatsApp অ্যাপ বা উপযুক্ত অ্যাপ খুলতে চেষ্টা করবে।
- প্রথম Build-এ যদি Gradle/SDK সংক্রান্ত ত্রুটি আসে, Actions log দেখে ঠিক করতে হবে।
- APK debug-signed হবে, ব্যক্তিগত ইনস্টল/টেস্টের জন্য উপযুক্ত। Play Store প্রকাশের জন্য আলাদা release signing প্রয়োজন।
